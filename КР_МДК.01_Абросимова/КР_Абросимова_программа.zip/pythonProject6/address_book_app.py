from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QListWidget, QPushButton, QDialog, QLineEdit
import mysql.connector
from main import Contact
from view_contact_dialog import ViewContactDialog
from add_edit_contact_dialog import AddEditContactDialog


class AddressBookApp(QMainWindow):
    def __init__(self, user_id):
        super().__init__()
        self.setWindowTitle("Записная книжка")
        self.resize(300, 400)

        self.user_id = user_id

        self.contacts = self.get_user_contacts()

        main_layout = QVBoxLayout()

        main_layout = QVBoxLayout()

        self.search_input = QLineEdit()
        self.search_input.textChanged.connect(self.search_contacts)

        main_layout.addWidget(self.search_input)  

        self.contacts_list = QListWidget()
        self.contacts_list.itemClicked.connect(self.view_contact)
        main_layout.addWidget(self.contacts_list)

        add_button = QPushButton("Добавить контакт")
        add_button.clicked.connect(self.add_contact)
        main_layout.addWidget(add_button)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        self.contacts = self.get_user_contacts()
        self.update_contacts_list()

    def search_contacts(self):
        search_text = self.search_input.text().strip().lower()

        self.contacts_list.clear()

        for contact in self.contacts:
            if search_text in contact.name.lower():
                self.contacts_list.addItem(contact.name)

    def get_user_contacts(self):
        contacts = []
        try:
            conn = mysql.connector.connect(
                host='127.0.0.1',
                user='root',
                database='phones'
            )

            if conn.is_connected():
                cursor = conn.cursor()
                select_query = "SELECT name, phone_number, notes FROM contacts WHERE user_id = %s"
                cursor.execute(select_query, (self.user_id,))
                user_contacts = cursor.fetchall()

                for contact in user_contacts:
                    contacts.append(Contact(contact[0], contact[1], contact[2]))

                cursor.close()
                conn.close()

        except mysql.connector.Error as error:
            print("Ошибка при работе с базой данных:", error)

        return contacts

    def add_contact(self):
        dialog = AddEditContactDialog(self, user_id=self.user_id)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.contacts.append(dialog.get_contact_info())
            self.update_contacts_list()

    def view_contact(self, item):
        index = self.contacts_list.row(item)
        contact = self.contacts[index]
        dialog = ViewContactDialog(self, contact)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.update_contacts_list()

    def update_contacts_list(self):
        self.contacts_list.clear()
        self.contacts = self.get_user_contacts()
        for contact in self.contacts:
            self.contacts_list.addItem(contact.name)

    def remove_contact_from_list(self, contact):
        self.contacts.remove(contact)
        self.update_contacts_list()


