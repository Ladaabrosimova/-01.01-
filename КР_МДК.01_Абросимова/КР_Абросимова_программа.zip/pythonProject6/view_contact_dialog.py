from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton, QMessageBox
import mysql.connector
from add_edit_contact_dialog import AddEditContactDialog


class ViewContactDialog(QDialog):
    def __init__(self, parent=None, contact=None):
        super().__init__(parent)
        self.setWindowTitle("Информация о контакте")

        layout = QVBoxLayout()

        self.name_label = QLabel()
        self.phone_label = QLabel()
        self.notes_label = QLabel()

        layout.addWidget(self.name_label)
        layout.addWidget(self.phone_label)
        layout.addWidget(self.notes_label)

        edit_button = QPushButton("Редактировать контакт")
        edit_button.clicked.connect(self.edit_contact)
        layout.addWidget(edit_button)

        delete_button = QPushButton("Удалить контакт")
        delete_button.clicked.connect(self.delete_contact)
        layout.addWidget(delete_button)

        self.setLayout(layout)

        self.contact = contact
        if contact:
            self.name_label.setText(f"Имя: {contact.name}")
            self.phone_label.setText(f"Телефон: {contact.phone_number}")
            self.notes_label.setText(f"Примечания: {contact.notes}")
            self.contact_id = self.get_contact_id_from_db(contact.name, contact.phone_number)

    def get_contact_id_from_db(self, name, phone_number):
        contact_id = None
        try:
            conn = mysql.connector.connect(
                host='127.0.0.1',
                user='root',
                database='phones'
            )

            if conn.is_connected():
                cursor = conn.cursor()
                select_query = "SELECT id FROM contacts WHERE name = %s AND phone_number = %s"
                cursor.execute(select_query, (name, phone_number))
                result = cursor.fetchone()
                if result:
                    contact_id = result[0]
                cursor.close()
                conn.close()

        except mysql.connector.Error as error:
            print("Ошибка при работе с базой данных:", error)

        return contact_id

    def edit_contact(self):
        dialog = AddEditContactDialog(parent=self, contact=self.contact, contact_id=self.contact_id)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            updated_contact = dialog.get_contact_info()
            self.name_label.setText(f"Имя: {updated_contact.name}")
            self.phone_label.setText(f"Телефон: {updated_contact.phone_number}")
            self.notes_label.setText(f"Примечания: {updated_contact.notes}")
            self.contact = updated_contact
            self.contact_id = self.get_contact_id_from_db(updated_contact.name, updated_contact.phone_number)

            QMessageBox.information(
                self, "Успех", "Контакт успешно изменен"
            )
            self.parent().update_contacts_list()  # Обновление списка контактов

            self.accept()

    def delete_contact(self):
        confirmation = QMessageBox.question(
            self, "Подтверждение удаления", "Вы уверены, что хотите удалить контакт?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if confirmation == QMessageBox.StandardButton.Yes:
            try:
                conn = mysql.connector.connect(
                    host='127.0.0.1',
                    user='root',
                    database='phones'
                )

                if conn.is_connected():
                    cursor = conn.cursor()
                    delete_query = "DELETE FROM contacts WHERE name = %s AND phone_number = %s AND notes = %s"
                    cursor.execute(delete_query, (self.contact.name, self.contact.phone_number, self.contact.notes))
                    conn.commit()
                    cursor.close()
                    conn.close()

                    QMessageBox.information(
                        self, "Успех", "Контакт успешно удален"
                    )
                    self.parent().remove_contact_from_list(self.contact)  # Remove from displayed list

                    self.accept()

            except mysql.connector.Error as error:
                QMessageBox.warning(
                    self, "Ошибка", f"Ошибка при удалении контакта: {error}"
                )
        else:
            pass

