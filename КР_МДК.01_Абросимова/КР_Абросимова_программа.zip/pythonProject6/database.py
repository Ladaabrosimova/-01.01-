import mysql.connector


def register_user_to_db(username, password):
    try:
        conn = mysql.connector.connect(
            host='127.0.0.1',
            user='root',
            database='phones'
        )

        if conn.is_connected():
            cursor = conn.cursor()
            insert_query = "INSERT INTO users (username, password) VALUES (%s, %s)"
            user_data = (username, password)
            cursor.execute(insert_query, user_data)
            conn.commit()
            print("Пользователь зарегистрирован успешно!")
            cursor.close()
            conn.close()
        else:
            print("Не удалось подключиться к базе данных.")

    except mysql.connector.Error as error:
        print("Ошибка при работе с базой данных:", error)


def add_contact_to_db(user_id, name, phone_number, notes):
    try:
        conn = mysql.connector.connect(
            host='127.0.0.1',
            user='root',
            database='phones'
        )

        if conn.is_connected():
            cursor = conn.cursor()
            insert_query = "INSERT INTO contacts (user_id, name, phone_number, notes) VALUES (%s, %s, %s, %s)"
            contact_data = (user_id, name, phone_number, notes)
            cursor.execute(insert_query, contact_data)
            conn.commit()
            print("Контакт добавлен успешно!")
            cursor.close()
            conn.close()
        else:
            print("Не удалось подключиться к базе данных.")

    except mysql.connector.Error as error:
        print("Ошибка при работе с базой данных:", error)


def update_contact_in_db(contact_id, name, phone_number, notes):
    try:
        conn = mysql.connector.connect(
            host='127.0.0.1',
            user='root',
            database='phones'
        )

        if conn.is_connected():
            cursor = conn.cursor()
            update_query = "UPDATE contacts SET name = %s, phone_number = %s, notes = %s WHERE id = %s"
            contact_data = (name, phone_number, notes, contact_id)
            cursor.execute(update_query, contact_data)
            conn.commit()
            print("Контакт обновлен успешно!")
            cursor.close()
            conn.close()
        else:
            print("Не удалось подключиться к базе данных.")

    except mysql.connector.Error as error:
        print("Ошибка при работе с базой данных:", error)

