from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QDialogButtonBox, QPushButton, QMessageBox
import mysql.connector
from registration_dialog import RegistrationDialog


class LoginDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.user_id = None
        self.setWindowTitle("Авторизация")

        layout = QVBoxLayout()

        self.username_input = QLineEdit()
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.authenticate)
        buttons.rejected.connect(self.reject)

        layout.addWidget(QLabel("Имя пользователя:"))
        layout.addWidget(self.username_input)
        layout.addWidget(QLabel("Пароль:"))
        layout.addWidget(self.password_input)
        layout.addWidget(buttons)

        register_button = QPushButton("Регистрация")
        register_button.clicked.connect(self.show_registration_dialog)
        layout.addWidget(register_button)

        self.setLayout(layout)

    def authenticate(self):
        username = self.username_input.text()
        password = self.password_input.text()

        try:
            conn = mysql.connector.connect(
                host='127.0.0.1',
                user='root',
                database='phones'
            )

            if conn.is_connected():
                cursor = conn.cursor()
                select_query = "SELECT id FROM users WHERE username = %s AND password = %s"
                cursor.execute(select_query, (username, password))
                user_id = cursor.fetchone()

                if user_id:
                    self.user_id = user_id[0]  # Получаем фактический user_id из результата запроса
                    self.accept()
                else:
                    QMessageBox.warning(self, "Ошибка", "Неверное имя пользователя или пароль")
                    self.username_input.clear()
                    self.password_input.clear()

                cursor.close()
                conn.close()

        except mysql.connector.Error as error:
            print("Ошибка при работе с базой данных:", error)

    def get_user_id(self, username):
        user_id = None
        try:
            conn = mysql.connector.connect(
                host='127.0.0.1',
                user='root',
                database='phones'
            )

            if conn.is_connected():
                cursor = conn.cursor()
                select_query = "SELECT id FROM users WHERE username = %s"
                cursor.execute(select_query, (username,))
                user_id = cursor.fetchone()

                cursor.close()
                conn.close()

        except mysql.connector.Error as error:
            print("Ошибка при работе с базой данных:", error)

        return user_id[0] if user_id else None

    def show_registration_dialog(self):
        registration_dialog = RegistrationDialog()
        registration_dialog.exec()

