import sys
from PyQt6.QtWidgets import QApplication, QDialog
from login_dialog import LoginDialog
from address_book_app import AddressBookApp


class Contact:
    def __init__(self, name, phone_number, notes):
        self.name = name
        self.phone_number = phone_number
        self.notes = notes


def main():
    app = QApplication(sys.argv)

    login_dialog = LoginDialog()
    if not login_dialog.exec() == QDialog.DialogCode.Accepted:
        sys.exit(-1)

    user_id = login_dialog.user_id

    window = AddressBookApp(user_id)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
