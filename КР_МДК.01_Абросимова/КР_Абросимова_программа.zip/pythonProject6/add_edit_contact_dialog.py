from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QTextEdit, QDialogButtonBox, QPushButton
from database import update_contact_in_db, add_contact_to_db
from main import Contact


class AddEditContactDialog(QDialog):
    def __init__(self, parent=None, contact=None, user_id=None, contact_id=None):
        super().__init__(parent)
        self.user_id = user_id
        self.contact_id = contact_id
        self.setWindowTitle("Добавить контакт" if not contact else "Редактировать контакт")

        layout = QVBoxLayout()

        self.name_input = QLineEdit()
        self.phone_input = QLineEdit()
        self.notes_input = QTextEdit()

        if contact:
            self.name_input.setText(contact.name)
            self.phone_input.setText(contact.phone_number)
            self.notes_input.setPlainText(contact.notes)

        layout.addWidget(QLabel("Имя:"))
        layout.addWidget(self.name_input)
        layout.addWidget(QLabel("Телефон:"))
        layout.addWidget(self.phone_input)
        layout.addWidget(QLabel("Примечания:"))
        layout.addWidget(self.notes_input)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.setLayout(layout)

    def get_contact_info(self):
        return Contact(self.name_input.text(), self.phone_input.text(), self.notes_input.toPlainText())

    def accept(self):
        contact_info = self.get_contact_info()
        if self.contact_id:  # Если contact_id существует, это операция редактирования
            update_contact_in_db(self.contact_id, contact_info.name, contact_info.phone_number, contact_info.notes)
        else:
            add_contact_to_db(self.user_id, contact_info.name, contact_info.phone_number, contact_info.notes)
        super().accept()

